#!/bin/sh

# Uninstall the Required C++ Runtimes & the Program "bcheck"
rm -rf        /usr/local/lib/bcheck/

rm -rf        /usr/local/bin/bcheck

# Uninstall the Documentation Files
rm -rf        /usr/local/share/man/man1/bcheck.1
rm -rf        /usr/local/share/bcheck/


