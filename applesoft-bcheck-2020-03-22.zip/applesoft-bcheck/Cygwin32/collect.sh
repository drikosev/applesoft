#!/bin/sh

# Collect the Required Libraries

for t in `/usr/bin/ldd bcheck | grep -o "/usr/bin/cyg.*.dll"   ` ; do  cp $t . ; done ;

