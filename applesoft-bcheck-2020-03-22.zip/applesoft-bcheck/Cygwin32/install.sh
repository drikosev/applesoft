#!/bin/sh

# Prepare the Installation Directores

 install -d /usr/local/bin/
 install -d /usr/local/lib/bcheck/
 install -d /usr/local/share/man/man1/
 install -d /usr/local/share/bcheck/

# Install the Program "bcheck"
 install -p -m 644  lib/C++-LGPL-v3.txt     /usr/local/lib/bcheck/C++-LGPL-v3.txt 
 install -p -m 755  bcheck                  /usr/local/bin/bcheck

# Install the Documentation Files
 install  -p -m 644 ../bcheck.1             /usr/local/share/man/man1/bcheck.1
 install  -p -m 644 ../bcheck.1.pdf         /usr/local/share/bcheck/user-manual.pdf
 install  -p -m 644 ../LICENSE.txt          /usr/local/share/bcheck/bcheck-license.txt
 install  -p -m 644 ../applesoft-parser.htm  /usr/local/share/bcheck/applesoft-parser.htm
 install  -p -m 644 ../applesoft-scanner.htm /usr/local/share/bcheck/applesoft-scanner.htm


