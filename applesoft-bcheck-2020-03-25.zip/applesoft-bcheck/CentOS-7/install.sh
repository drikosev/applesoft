#!/bin/sh

# Prepare the Installation Directores

sudo install -d /usr/local/lib/bcheck/
sudo install -d /usr/local/bin/
sudo install -d /usr/local/share/man/man1/
sudo install -d /usr/local/share/bcheck/

# Install the Program "bcheck" and a notice about the C++ library
sudo install -p -m 644  lib/C++-LGPL-v3.txt     /usr/local/lib/bcheck/C++-LGPL-v3.txt 
sudo install -p -m 755  bcheck                  /usr/local/bin/bcheck

# Install the Documentation Files
sudo install  -p -m 644 ../bcheck.1             /usr/local/share/man/man1/bcheck.1
sudo install  -p -m 644 ../bcheck.1.pdf         /usr/local/share/bcheck/user-manual.pdf
sudo install  -p -m 644 ../LICENSE.txt          /usr/local/share/bcheck/bcheck-license.txt
sudo install  -p -m 644 ../applesoft-parser.htm   /usr/local/share/bcheck/applesoft-parser.htm
sudo install  -p -m 644 ../applesoft-scanner.htm  /usr/local/share/bcheck/applesoft-scanner.htm
