#!/bin/sh

# Uninstall the Required C++ Runtimes & the Program "bcheck"
sudo rm -rf        /usr/local/lib/bcheck/

sudo rm -rf        /usr/local/bin/bcheck

# Uninstall the Documentation Files
sudo rm -rf        /usr/local/share/man/man1/bcheck.1
sudo rm -rf        /usr/local/share/bcheck/


